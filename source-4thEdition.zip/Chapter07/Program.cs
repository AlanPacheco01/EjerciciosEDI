﻿using JonSkeet.DemoUtil;
using System;

namespace Chapter07
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}
