﻿using JonSkeet.DemoUtil;

namespace Chapter02
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}