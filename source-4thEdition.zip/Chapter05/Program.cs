﻿using JonSkeet.DemoUtil;

namespace Chapter05
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}