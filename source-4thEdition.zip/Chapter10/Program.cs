﻿using JonSkeet.DemoUtil;

namespace Chapter10
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}
